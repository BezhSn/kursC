document.getElementById("sidebar").innerHTML = '\
        <header> \
        <div class="container">\
            <div class="header">\
                <div class="row">\
                    <div class="col-lg-2">\
                        <a href="../index.html" class="header_logo">C# - программирование</a>\
                    </div>\
                    <div class="col-lg-10">\
                        <div class="header_menu">\
                            <a href="../lessons/leson.html" class="header_text">Лекции</a>\
                            <a href="../lab_rab/lab_rab.html" class="header_text">Лабораторные работы по С#</a>\
                            <a href="../lessons/test.html" class="header_text">Итоговый тест</a>\
                            <a href="https://www.onlinegdb.com/online_csharp_compiler" class="header_text" target="_blank">Онлайн - компилятор С#</a>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>\
        </header>'
