$(document).ready(function(){

    //Modal

    $('[data-modal=enter]').on('click', function() {
        $('.overlay, #enter').fadeIn('slow');
    });
    $('.modal_close').on('click', function() {
        $('.overlay, #enter').fadeOut('slow');
    });


    //Validate

    function valideForms(form) {
        $(form).validate({
            rules: {
                name: "required",
                email:{
                    required: true,
                    email: true
                }
            },
            messages: {
                name: "Пожалуйста, введите своё имя",
                email: {
                  required: "Пожалуйста, введите свою почту",
                  email: "Неправильно введен адрес почты"
                }
            }
        });
    };

    valideForms('#enter-form');
    valideForms('#enter form');


    $('form').submit(function(e) {
        e.preventDefault();
        
        $.ajax({
            type: "POST",
            url: "mailer/smart.php",
            data: $(this).serialize()
        }).done(function() {
            $(this).find("input, textarea").val("");
            $('#enter, .overlay').fadeOut();

            $('form').trigger('reset');
        });
        return false;
    });
});

